Hello! My project 3 can pass all the tests of "TestBitwise" and "TestMyFileSystem".

For part 1, I supplemented all the methods that need to be fixed such as ones named "isset", "set", "clear", "clearAll", 
and "toString". 

For part 2, in the "MyFileSystem.java" class, I changed "getDirectBlock()" method to support the large file. I extended the 
file size by adding single-indirection, double-indirection, and triple-indirection. 

Thank you!
